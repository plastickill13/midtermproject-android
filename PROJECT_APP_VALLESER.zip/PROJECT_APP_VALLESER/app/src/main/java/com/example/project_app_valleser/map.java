package com.example.project_app_valleser;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class map extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener {

    private GoogleMap myMap;
    private String deliveryAddress;
    private Marker currentMarker;
    private Button confirmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        confirmButton = findViewById(R.id.button);

        // Initialize the map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Toast.makeText(map.this, "Map Fragment is null!", Toast.LENGTH_LONG).show();
        }

        // Set up confirm button functionality
        confirmButton.setOnClickListener(v -> {
            if (deliveryAddress != null && !deliveryAddress.equals("Unknown Address")) {
                Intent a = new Intent(map.this, Confirmation.class);
                startActivity(a);
            } else {
                Toast.makeText(map.this, "Please select a valid address on the map!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        myMap = googleMap;


        LatLng boholLatLng = new LatLng(9.8863, 123.8746);
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(boholLatLng, 15));


        myMap.setOnMapClickListener(this);
    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {

        if (currentMarker != null) {
            currentMarker.remove();
        }


        currentMarker = myMap.addMarker(new MarkerOptions().position(latLng).title("Delivery Location"));


        deliveryAddress = getAddressFromLocation(latLng);
    }

    private String getAddressFromLocation(LatLng latLng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        try {
            addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                return address.getAddressLine(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Unknown Address";
    }
}
