package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.LinkedList;

public class Activity2 extends AppCompatActivity {

    RadioButton rd1,rd2,rd3;
    TextView list,tots,dis;
    Button checkout;
    CheckBox fries,chicken,burger,nuggets,hotdog,coke,sprite,icedtea,combo1,combo2,combo3,combo4;
    double total = 0,tot = 0;
    LinkedList cart;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);

        fries = findViewById(R.id.fries);
        chicken = findViewById(R.id.chicken);
        burger = findViewById(R.id.burger);
        nuggets = findViewById(R.id.nuggets);
        hotdog = findViewById(R.id.hotdog);
        coke = findViewById(R.id.coke);
        sprite = findViewById(R.id.sprite);
        icedtea = findViewById(R.id.icedtea);
        combo1 = findViewById(R.id.combo1);
        combo2 = findViewById(R.id.combo2);
        combo3 = findViewById(R.id.combo3);
        combo4 = findViewById(R.id.combo4);
        list = findViewById(R.id.itemlist);
        checkout = findViewById(R.id.checkout_btn);
        rd1 = findViewById(R.id.rb1);
        rd2 = findViewById(R.id.rb2);
        rd3 = findViewById(R.id.rb3);
        tots = findViewById(R.id.tots);
        dis = findViewById(R.id.discount);



        cart = new LinkedList();

        fries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fries.isChecked()){
                    total +=20.00;
                    tots.setText(""+total);
                    cart.add("Fries");

                    list.setText(cart.toString());
                } else {
                    total -=20.00;
                    tots.setText(""+total);
                    cart.remove("Fries");
                    list.setText(cart.toString());
                }

            }
        });

        chicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chicken.isChecked()){
                    total +=30.00;
                    tots.setText(""+total);
                    cart.add("Chicken");
                    list.setText(cart.toString());
                } else {
                    total -=30.00;
                    tots.setText(""+total);
                    cart.remove("Chicken");
                    list.setText(cart.toString());
                }

            }
        });

        burger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(burger.isChecked()){
                    total +=29.50;
                    tots.setText(""+total);
                    cart.add("Burger");
                    list.setText(cart.toString());
                } else {
                    total -=29.50;
                    tots.setText(""+total);
                    cart.remove("Burger");
                    list.setText(cart.toString());
                }

            }
        });


        nuggets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nuggets.isChecked()){
                    total +=35.00;
                    tots.setText(""+total);
                    cart.add("Nuggets");
                    list.setText(cart.toString());
                } else {
                    total -=35.00;
                    tots.setText(""+total);
                    cart.remove("Nuggets");
                    list.setText(cart.toString());
                }

            }
        });

        hotdog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hotdog.isChecked()){
                    total +=29.32;
                    tots.setText(""+total);
                    cart.add("Hotdog");
                    list.setText(cart.toString());
                } else {
                    total -=29.32;
                    tots.setText(""+total);
                    cart.remove("Hotdog");
                    list.setText(cart.toString());
                }

            }
        });


        coke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(coke.isChecked()){
                    total +=19.00;
                    tots.setText(""+total);
                    cart.add("Coke");
                    list.setText(cart.toString());
                } else {
                    total -=19.00;
                    tots.setText(""+total);
                    cart.remove("Coke");
                    list.setText(cart.toString());
                }

            }
        });


        sprite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sprite.isChecked()){
                    total +=20.32;
                    tots.setText(""+total);
                    cart.add("Sprite");
                    list.setText(cart.toString());
                } else {
                    total -=20.32;
                    tots.setText(""+total);
                    cart.remove("Sprite");
                    list.setText(cart.toString());
                }

            }
        });


        icedtea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(icedtea.isChecked()){
                    total +=19.00;
                    tots.setText(""+total);
                    cart.add("Icedtea");
                    list.setText(cart.toString());
                } else {
                    total -=19.00;
                    tots.setText(""+total);
                    cart.remove("Icedtea");
                    list.setText(cart.toString());
                }

            }
        });

        combo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(combo1.isChecked()){
                    total +=70.00;
                    tots.setText(""+total);
                    cart.add("Combo1");
                    list.setText(cart.toString());
                } else {
                    total -=70.00;
                    tots.setText(""+total);
                    cart.remove("Combo1");
                    list.setText(cart.toString());
                }

            }
        });

        combo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(combo2.isChecked()){
                    total +=89.00;
                    tots.setText(""+total);
                    cart.add("Combo2");
                    list.setText(cart.toString());
                } else {
                    total -=89.00;
                    tots.setText(""+total);
                    cart.remove("Combo2");
                    list.setText(cart.toString());
                }

            }
        });

        combo3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(combo3.isChecked()){
                    total +=85.00;
                    tots.setText(""+total);
                    cart.add("Combo3");
                    list.setText(cart.toString());
                } else {
                    total -=85.00;
                    tots.setText(""+total);
                    cart.remove("Combo3");
                    list.setText(cart.toString());
                }

            }
        });


        combo4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(combo4.isChecked()){
                    total +=88.00;
                    cart.add("Combo4");
                    tots.setText(""+total);
                    list.setText(cart.toString());
                } else {
                    total -=88.00;
                    tots.setText(""+total);
                    cart.remove("Combo4");
                    list.setText(cart.toString());
                }

            }
        });

        rd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rd1.isChecked()){
                    double discountamt = 0;
                    discountamt = total * .03;
                    dis.setText(""+discountamt);
                    total = total - discountamt;

                }
            }
        });


        rd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rd2.isChecked()){
                    double discountamt = 0;
                    discountamt = total * .01;
                    dis.setText(""+discountamt);
                    total = total - discountamt;


                }
            }
        });


        rd3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rd3.isChecked()){
                    double  discountamt = 0;
                    discountamt = total * .02;
                    dis.setText(""+discountamt);
                    total = total - discountamt;

                }
            }
        });


        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(rd1.isChecked()){

                    Intent a = new Intent(Activity2.this, Checkout.class);
                    a.putExtra("total",tots.getText().toString());
                    a.putExtra("discount",dis.getText().toString());
                    startActivity(a);



                }

                if(rd2.isChecked()){

                    Intent a = new Intent(Activity2.this, cod.class);
                    a.putExtra("total",tots.getText().toString());
                    a.putExtra("discount",dis.getText().toString());
                    startActivity(a);



                }

                if(rd3.isChecked()){

                    Intent a = new Intent(Activity2.this, ewallet.class);
                    a.putExtra("total",tots.getText().toString());
                    a.putExtra("discount",dis.getText().toString());
                    startActivity(a);



                }


            }
        });






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}