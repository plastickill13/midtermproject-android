package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class cod extends AppCompatActivity {

    EditText name;
    TextView grandtotal,subtotal,discount,shopfee,finaltotal;
    Button pay;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cod);


        name = findViewById(R.id.receivername);
        pay = findViewById(R.id.pay_btn);
        grandtotal = findViewById(R.id.grandtotal);
        subtotal = findViewById(R.id.subtotal);
        discount = findViewById(R.id.discount);
        shopfee = findViewById(R.id.shopfee);
        finaltotal = findViewById(R.id.finaltotal);


        String getTotal = getIntent().getExtras().getString("total");
        String getDiscount = getIntent().getExtras().getString("discount");
        double d = Double.parseDouble(getDiscount);
        double t = Double.parseDouble(getTotal);
        double shopfe = 2.19;
        double gtotal= t-d-shopfe;

        grandtotal.setText(String.format("₱%.2f",gtotal));
        subtotal.setText(String.format("₱%.2f",t));
        discount.setText(String.format("₱%.2f",d));
        shopfee.setText(String.format("₱%.2f",shopfe));
        finaltotal.setText(String.format("₱%.2f",gtotal));



        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(name.getText().toString())){
                    name.setError("Receiver's Name is Required!");
                }else {

                    Intent a = new Intent(cod.this, map.class);
                    startActivity(a);

                }


            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}