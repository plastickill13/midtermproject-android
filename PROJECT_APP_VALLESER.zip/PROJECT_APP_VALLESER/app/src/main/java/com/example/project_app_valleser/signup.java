package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class signup extends AppCompatActivity {

    EditText name,email,pass;
    TextView login;
    Button signup;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);

        login = findViewById(R.id.login);
        name = findViewById(R.id.name_et);
        email = findViewById(R.id.email_et);
        pass = findViewById(R.id.pass_et);
        signup = findViewById(R.id.signup_btn);



        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(name.getText().toString())){
                    name.setError("Name is required!");
                    return;
                }

                if(TextUtils.isEmpty(email.getText().toString())){
                    email.setError("Email is required!");
                    return;
                }

                if(TextUtils.isEmpty(pass.getText().toString())){
                    pass.setError("Password is required!");
                    return;
                }
                    Intent a = new Intent(signup.this, welcome.class);
                    startActivity(a);

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    Intent a = new Intent(signup.this, MainActivity.class);
                    startActivity(a);


            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}