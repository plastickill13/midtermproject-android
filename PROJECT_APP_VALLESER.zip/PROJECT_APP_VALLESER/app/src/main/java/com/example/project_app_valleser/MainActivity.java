package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    EditText email,password;
    Button login;
    CheckBox checkboxbtn;
    TextView signup,forgotpass,about;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        checkboxbtn = findViewById(R.id.checkbox);
        email = findViewById(R.id.email_et);
        password = findViewById(R.id.password_et);
        login = findViewById(R.id.login_btn);
        signup = findViewById(R.id.signup);
        forgotpass = findViewById(R.id.forgotpass);
        about = findViewById(R.id.about);


        checkboxbtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {

             if(b){

                 password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
             }else{
                 password.setInputType(InputType.TYPE_CLASS_TEXT| InputType.TYPE_TEXT_VARIATION_PASSWORD);
             }

            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             if(email.getText().toString().equals("test@gmail.com")&&password.getText().toString().equals("123456")){
                 Intent a = new Intent(MainActivity.this,Activity2.class);
                 startActivity(a);
             }else{

                 AlertDialog.Builder ad =new AlertDialog.Builder(MainActivity.this);

                 ad.setTitle("Warning!");
                 ad.setMessage("Please input correct username and password!");
                 ad.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                     @Override
                     public void onClick(DialogInterface dialog, int which) {

                    email.setText("");
                    password.setText("");
                    dialog.dismiss();
                     }
                 });
                    AlertDialog dialogs =ad.create();
                    dialogs.show();


             }

            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(MainActivity.this,signup.class);
                startActivity(a);
            }
        });

        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent a = new Intent(MainActivity.this,forgotpass.class);
                startActivity(a);

            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent a = new Intent(MainActivity.this,about.class);
                startActivity(a);


            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}