package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ewallet extends AppCompatActivity {

    TextView subtotal,discount,grandtotal;
    Button paybtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ewallet);

        subtotal = findViewById(R.id.subtotal);
        discount = findViewById(R.id.discount);
        grandtotal = findViewById(R.id.grandtotal);
        paybtn = findViewById(R.id.paybtn);


        String getTotal = getIntent().getExtras().getString("total");
        String getDiscount = getIntent().getExtras().getString("discount");
        double d = Double.parseDouble(getDiscount);
        double t = Double.parseDouble(getTotal);
        double gtotal= t-d;

        grandtotal.setText(String.format("₱%.2f",gtotal));
        subtotal.setText(String.format("₱%.2f",t));
        discount.setText(String.format("₱%.2f",d));




        paybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent a = new Intent(ewallet.this, map.class);
                startActivity(a);


            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}