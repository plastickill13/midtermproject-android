package com.example.project_app_valleser;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class createnewpass extends AppCompatActivity {

    EditText newpass,confirmpass;
    Button savebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_createnewpass);

        newpass = findViewById(R.id.newpass);
        confirmpass = findViewById(R.id.confirmpass);
        savebtn = findViewById(R.id.savebtn);



        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newPassword = newpass.getText().toString();
                String confirmPassword = confirmpass.getText().toString();

                if (TextUtils.isEmpty(newPassword)) {
                    newpass.setError("Please Input New Password!");
                    return;
                }

                if (TextUtils.isEmpty(confirmPassword)) {
                    confirmpass.setError("Please Confirm Your Password!");
                    return;
                }

                if (!newPassword.equals(confirmPassword)) {
                    confirmpass.setError("Password Doesn't match!");
                    return;
                }

                Intent a = new Intent(createnewpass.this, MainActivity.class);
                startActivity(a);
            }
        });




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}