package com.example.project_app_valleser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Checkout extends AppCompatActivity {

    EditText name,cardnum,date;
    TextView subtotal,discount,shopfee,grandtotal,finaltotal;
    Button paybtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_checkout);

        name = findViewById(R.id.holdername);
        cardnum = findViewById(R.id.cardnum);
        date = findViewById(R.id.expiration);
        subtotal = findViewById(R.id.subtotal);
        discount = findViewById(R.id.discount);
        shopfee = findViewById(R.id.shopfee);
        grandtotal = findViewById(R.id.grandtotal);
        finaltotal = findViewById(R.id.finaltotal);
        paybtn = findViewById(R.id.pay_btn);


        String getTotal = getIntent().getExtras().getString("total");
        String getDiscount = getIntent().getExtras().getString("discount");
        double d = Double.parseDouble(getDiscount);
        double t = Double.parseDouble(getTotal);
        double shopfe = 2.19;
        double gtotal= t-d-shopfe;

        grandtotal.setText(String.format("₱%.2f",gtotal));
        subtotal.setText(String.format("₱%.2f",t));
        discount.setText(String.format("₱%.2f",d));
        shopfee.setText(String.format("₱%.2f",shopfe));
        finaltotal.setText(String.format("₱%.2f",gtotal));


        paybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(name.getText().toString())){
                    name.setError("Name is required!");
                    return;
                }

                if(TextUtils.isEmpty(cardnum.getText().toString())){
                    cardnum.setError("Card Number is required!");
                    return;
                }

                if(TextUtils.isEmpty(date.getText().toString())){
                    date.setError("Date is required!");
                    return;
                }

                Intent a = new Intent(Checkout.this, map.class);
                startActivity(a);

            }
        });








        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}